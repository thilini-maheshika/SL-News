Read me....!
My website has feedback facilities.I used php for that.In that case ,it need use server for get result.And also import 
database for proper work in my web site.

Login Username & password for admin panel.

	Username:ADMIN
	Password:12345

That have another view for editor to access site feedback.It registration can do,when goes to admin panel.

SL News.News web protal.
Design By : K.Thilini Maheshika | Faculty of Technology | South Eastern University of Sri Lanka 
Email : kthilini1999@gmail.com 
				